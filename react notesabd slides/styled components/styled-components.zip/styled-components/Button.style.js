import React from 'react'
import styled from 'styled-components'

//single button
export  const Button=styled.button`
width:200px;
height:100px ;
background-color: red;
 


`;
//multiple button examples 1
export  const GreenButton=styled.button`
width:200px;
height:100px ;
background-color: green;
 


`;
//multiple button examples 2
export  const BlueButton=styled.button`
width:200px;
height:100px ;
background-color: blue;
 


`;

//button ex with props
export  const Button2=styled.button`
width:200px;
height:100px ;
background-color: ${(props)=>props.backgroundcolor};
 


`;